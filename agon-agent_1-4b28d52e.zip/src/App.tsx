import Navbar from './components/Navbar';
import Hero from './components/Hero';
import TrustBar from './components/TrustBar';
import ProductOverview from './components/ProductOverview';
import CoreFeatures from './components/CoreFeatures';
import ProductShowcase from './components/ProductShowcase';
import UseCases from './components/UseCases';
import Customization from './components/Customization';
import Commerce from './components/Commerce';
import Analytics from './components/Analytics';
import AISupport from './components/AISupport';
import Pricing from './components/Pricing';
import FinalCTA from './components/FinalCTA';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-cream">
      <Navbar />
      <main>
        <Hero />
        <TrustBar />
        <ProductOverview />
        <CoreFeatures />
        <ProductShowcase />
        <UseCases />
        <Customization />
        <Commerce />
        <Analytics />
        <AISupport />
        <Pricing />
        <FinalCTA />
      </main>
      <Footer />
    </div>
  );
}

export default App;
