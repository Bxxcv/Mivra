import { Link2, Store, CreditCard, Users, BarChart3, MessagesSquare } from 'lucide-react';
import Container from './ui/Container';
import Eyebrow from './ui/Eyebrow';

const pillars = [
  {
    icon: Link2,
    title: 'Link-in-bio page',
    desc: 'A fast, on-brand personal page that replaces every scattered link with one home base.',
  },
  {
    icon: Store,
    title: 'Storefront & catalog',
    desc: 'Sell digital downloads, physical goods, services, and bundles side by side.',
  },
  {
    icon: CreditCard,
    title: 'Checkout & payments',
    desc: 'Accept cards, wallets, and local payment methods with instant, secure checkout.',
  },
  {
    icon: Users,
    title: 'Orders & customers',
    desc: 'Track every order, manage buyers, and automate delivery without spreadsheets.',
  },
  {
    icon: BarChart3,
    title: 'Analytics & insights',
    desc: 'See what content, links, and products actually drive revenue — in real time.',
  },
  {
    icon: MessagesSquare,
    title: 'AI-powered support',
    desc: 'A trained assistant that answers customer questions for you, day or night.',
  },
];

export default function ProductOverview() {
  return (
    <section id="product" className="scroll-mt-24 py-20 sm:py-28">
      <Container>
        <div className="mx-auto max-w-2xl text-center">
          <Eyebrow>The Mivra platform</Eyebrow>
          <h2 className="text-balance mt-5 font-display text-3xl font-bold tracking-tight text-ink sm:text-[44px]">
            One platform. Every tool your business needs.
          </h2>
          <p className="mt-4 text-[16px] leading-relaxed text-ink-600">
            Mivra isn't another link-in-bio tool. It's the operating system behind
            your page — commerce, payments, customers, and support, all connected.
          </p>
        </div>

        <div className="mt-14 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {pillars.map(({ icon: Icon, title, desc }) => (
            <div
              key={title}
              className="group rounded-3xl border border-ink/8 bg-white p-7 shadow-soft transition-all hover:-translate-y-1 hover:border-amber-300/60 hover:shadow-card"
            >
              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-ink text-amber-400 transition-colors group-hover:bg-amber-500 group-hover:text-ink">
                <Icon className="h-5 w-5" />
              </div>
              <h3 className="mt-5 font-display text-[18px] font-bold text-ink">{title}</h3>
              <p className="mt-2 text-[14.5px] leading-relaxed text-ink-400">{desc}</p>
            </div>
          ))}
        </div>
      </Container>
    </section>
  );
}
