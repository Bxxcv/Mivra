import { useState } from 'react';
import { Check, Sparkles } from 'lucide-react';
import Container from './ui/Container';
import Eyebrow from './ui/Eyebrow';

const plans = [
  {
    name: 'Starter',
    tagline: 'For anyone just getting started',
    monthly: 0,
    yearly: 0,
    features: [
      '1 Mivra page',
      'Unlimited links',
      'Up to 3 products',
      'Basic themes',
      'Standard checkout',
      'Community support',
    ],
    cta: 'Start for free',
    highlighted: false,
  },
  {
    name: 'Creator',
    tagline: 'For growing creators & sellers',
    monthly: 12,
    yearly: 9,
    features: [
      'Everything in Starter',
      'Unlimited products',
      'Custom domain',
      'Full theme customization',
      'Advanced analytics',
      'Wallet & instant withdrawals',
      'Priority support',
    ],
    cta: 'Start free trial',
    highlighted: true,
  },
  {
    name: 'Business',
    tagline: 'For teams & serious operations',
    monthly: 39,
    yearly: 31,
    features: [
      'Everything in Creator',
      'AI-powered customer support',
      'Multiple team members',
      'Multi-currency checkout',
      'API & integrations',
      'Dedicated account manager',
    ],
    cta: 'Talk to sales',
    highlighted: false,
  },
];

export default function Pricing() {
  const [yearly, setYearly] = useState(true);

  return (
    <section id="pricing" className="scroll-mt-24 py-20 sm:py-28">
      <Container>
        <div className="mx-auto max-w-2xl text-center">
          <Eyebrow>Pricing</Eyebrow>
          <h2 className="text-balance mt-5 font-display text-3xl font-bold tracking-tight text-ink sm:text-[44px]">
            Simple pricing that grows with you.
          </h2>
          <p className="mt-4 text-[16px] leading-relaxed text-ink-600">
            Start free, upgrade only when your business needs more. No hidden
            transaction fees on paid plans.
          </p>

          <div className="mt-8 inline-flex items-center gap-1 rounded-full border border-ink/10 bg-white p-1.5 shadow-soft">
            <button
              onClick={() => setYearly(false)}
              className={`rounded-full px-5 py-2 text-[13.5px] font-semibold transition-colors ${
                !yearly ? 'bg-ink text-cream' : 'text-ink-500'
              }`}
            >
              Monthly
            </button>
            <button
              onClick={() => setYearly(true)}
              className={`flex items-center gap-1.5 rounded-full px-5 py-2 text-[13.5px] font-semibold transition-colors ${
                yearly ? 'bg-ink text-cream' : 'text-ink-500'
              }`}
            >
              Yearly
              <span className="rounded-full bg-amber-400 px-2 py-0.5 text-[10.5px] font-bold text-ink">
                Save 25%
              </span>
            </button>
          </div>
        </div>

        <div className="mt-14 grid grid-cols-1 gap-6 lg:grid-cols-3">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={`relative flex flex-col rounded-3xl border p-8 ${
                plan.highlighted
                  ? 'border-amber-400 bg-ink text-cream shadow-[0_30px_60px_-20px_rgba(23,20,15,0.4)] lg:-translate-y-3'
                  : 'border-ink/8 bg-white text-ink shadow-soft'
              }`}
            >
              {plan.highlighted && (
                <span className="absolute -top-3.5 left-1/2 flex -translate-x-1/2 items-center gap-1 rounded-full bg-amber-400 px-3.5 py-1.5 text-[11.5px] font-bold text-ink">
                  <Sparkles className="h-3 w-3" /> Most popular
                </span>
              )}

              <p className={`font-display text-[19px] font-bold ${plan.highlighted ? 'text-cream' : 'text-ink'}`}>
                {plan.name}
              </p>
              <p className={`mt-1 text-[13.5px] ${plan.highlighted ? 'text-cream/60' : 'text-ink-400'}`}>
                {plan.tagline}
              </p>

              <div className="mt-6 flex items-end gap-1.5">
                <span className="font-display text-[42px] font-bold leading-none">
                  ${yearly ? plan.yearly : plan.monthly}
                </span>
                <span className={`pb-1.5 text-[13.5px] ${plan.highlighted ? 'text-cream/60' : 'text-ink-400'}`}>
                  / month
                </span>
              </div>
              {plan.monthly > 0 && (
                <p className={`mt-1 text-[12px] ${plan.highlighted ? 'text-cream/50' : 'text-ink-400'}`}>
                  Billed {yearly ? 'yearly' : 'monthly'}
                </p>
              )}

              <a
                href="#cta"
                className={`mt-7 flex w-full items-center justify-center rounded-full py-3 text-[14.5px] font-semibold transition-all ${
                  plan.highlighted
                    ? 'bg-amber-400 text-ink hover:bg-amber-300'
                    : 'bg-ink text-cream hover:bg-amber-500 hover:text-ink'
                }`}
              >
                {plan.cta}
              </a>

              <ul className="mt-8 flex flex-col gap-3">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-start gap-2.5 text-[13.5px]">
                    <Check
                      className={`mt-0.5 h-4 w-4 shrink-0 ${
                        plan.highlighted ? 'text-amber-400' : 'text-forest-500'
                      }`}
                    />
                    <span className={plan.highlighted ? 'text-cream/85' : 'text-ink-600'}>{f}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <p className="mt-10 text-center text-[14px] text-ink-400">
          Need a custom plan for an agency or marketplace? {' '}
          <a href="#cta" className="font-semibold text-ink underline decoration-amber-400 decoration-2 underline-offset-4">
            Contact sales
          </a>
        </p>
      </Container>
    </section>
  );
}
