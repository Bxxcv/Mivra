import { BarChart3, MousePointerClick, TrendingUp, Users2 } from 'lucide-react';
import Container from './ui/Container';
import Eyebrow from './ui/Eyebrow';
import AnalyticsMockup from './mockups/AnalyticsMockup';

const points = [
  {
    icon: MousePointerClick,
    title: 'Traffic & click tracking',
    desc: 'See exactly which links, products, and blocks your visitors engage with.',
  },
  {
    icon: TrendingUp,
    title: 'Revenue & conversion analytics',
    desc: 'Follow the full path from visit to click to purchase, in one clear funnel.',
  },
  {
    icon: BarChart3,
    title: 'Top performers, ranked',
    desc: 'Instantly know your best-selling products and highest-converting links.',
  },
  {
    icon: Users2,
    title: 'Audience insights',
    desc: 'Understand where your buyers come from — device, location, and referral source.',
  },
];

export default function Analytics() {
  return (
    <section id="analytics" className="scroll-mt-24 py-20 sm:py-28">
      <Container>
        <div className="grid grid-cols-1 items-center gap-14 lg:grid-cols-2 lg:gap-16">
          <div className="order-2 lg:order-1">
            <AnalyticsMockup />
          </div>

          <div className="order-1 lg:order-2">
            <Eyebrow icon={<BarChart3 className="h-3.5 w-3.5" />}>Analytics &amp; insights</Eyebrow>
            <h2 className="text-balance mt-5 font-display text-3xl font-bold tracking-tight text-ink sm:text-[40px]">
              Know what's working, in real time.
            </h2>
            <p className="mt-4 max-w-lg text-[16px] leading-relaxed text-ink-600">
              Stop guessing which content sells. Mivra turns every click and
              checkout into a clear signal you can act on.
            </p>

            <div className="mt-8 flex flex-col gap-6">
              {points.map(({ icon: Icon, title, desc }) => (
                <div key={title} className="flex gap-4">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-50 text-amber-600">
                    <Icon className="h-4.5 w-4.5" />
                  </div>
                  <div>
                    <p className="text-[15px] font-bold text-ink">{title}</p>
                    <p className="mt-1 text-[14px] leading-relaxed text-ink-400">{desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}
